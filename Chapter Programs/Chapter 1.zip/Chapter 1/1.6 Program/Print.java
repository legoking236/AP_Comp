
/**
 * 
 * 
 * @author Alex Probst
 * @version 0.0.0
 */
public class Print
{
    public static void main (String[] args) {
        System.out.println ("JJJJJJJJJJJJJJJJJJJJ      AAAAA          LLLL");
        System.out.println ("JJJJJJJJJJJJJJJJJJJJ    AAAAAAAAA        LLLL");
        System.out.println ("        JJJJ          AAA       AAA      LLLL");
        System.out.println ("        JJJJ         AAA         AAA     LLLL");
        System.out.println ("        JJJJ         AAA         AAA     LLLL");
        System.out.println ("        JJJJ         AAA         AAA     LLLL");
        System.out.println ("        JJJJ         AAAAAAAAAAAAAAA     LLLL");
        System.out.println ("        JJJJ         AAAAAAAAAAAAAAA     LLLL");
        System.out.println ("JJJJ    JJJJ         AAA         AAA     LLLL");
        System.out.println (" JJJJ   JJJJ         AAA         AAA     LLLL");
        System.out.println ("   JJJJJJJJ          AAA         AAA     LLLLLLLLLLLLLLL");
        System.out.println ("     JJJJ            AAA         AAA     LLLLLLLLLLLLLLL");
    }
    
}
